package com.example.act5;

public class ClassNama {
    private String Nama;
    public  ClassNama(String  nama){
        this.Nama = nama;
    }
    public String getNama(){
        return  this.Nama;
    }
}